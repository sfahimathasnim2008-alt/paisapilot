import {useState,useEffect,useRef} from 'react'
import {CATS,fmt,clamp,RISK,RC,HL,M,ap,clone,init,charge,rollEvent,resetSeed,insights} from './logic'

const KEY='paisapilot-v1'
const load=()=>{try{const j=localStorage.getItem(KEY);return j?JSON.parse(j):null}catch{return null}}
const PRE=[['spend','Concert ticket',1200],['spend','Weekend food delivery',450],['spend','New sneakers',3500],['sub','Disney+ Hotstar',299]]

function Chart({S,m}){
  const W=320,H=130,P=22
  const pts=[...S.hist.map((v,i)=>[i+1,v]),[S.day,S.bal]]
  const mn=Math.min(...pts.map(p=>p[1]),m.end,0),mx=10000
  const X=d=>P+(d-1)/29*(W-P-6),Y=v=>H-P-(v-mn)/(mx-mn)*(H-P-8)
  const line=pts.map((p,i)=>(i?'L':'M')+X(p[0]).toFixed(1)+','+Y(p[1]).toFixed(1)).join(' ')
  const c=m.end<0?'var(--bad)':'var(--ac2)'
  return <svg viewBox={`0 0 ${W} ${H}`}>
    <line x1={P} x2={W-6} y1={Y(0)} y2={Y(0)} stroke="var(--bad)" strokeDasharray="3 3" opacity=".6"/>
    <path d={line} fill="none" stroke="var(--ac)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
    <line x1={X(S.day)} y1={Y(S.bal)} x2={X(30)} y2={Y(m.end)} stroke={c} strokeWidth="3" strokeDasharray="6 5" strokeLinecap="round"/>
    <circle cx={X(S.day)} cy={Y(S.bal)} r="5" fill="var(--ac)"/><circle cx={X(30)} cy={Y(m.end)} r="5" fill={c}/>
    <text x={P} y={H-4} fontSize="10" fill="var(--mut)">Day 1</text><text x={W-30} y={H-4} fontSize="10" fill="var(--mut)">Day 30</text></svg>
}

function Home({S,m,cat,setCat,onLog,onEnd,onPay}){
  const [amt,setAmt]=useState('')
  const left=S.todayAllow-S.spent,hl=HL(m.health)
  return <>
    {S.event&&<div className="card alert"><h3>{S.event.i} Surprise: {S.event.n}</h3>
      <div className="big" style={{fontSize:28}}>{fmt(S.event.a)}</div>
      <p className="mut">Unexpected expenses hit everyone. Choose how to absorb it.</p>
      <div className="row"><button className="btn" onClick={()=>onPay('bal')}>Pay from balance</button>
      <button className="btn g" onClick={()=>onPay('ef')}>Use emergency fund ({fmt(S.goals[0].saved)})</button></div></div>}
    <div className="card hero">
      <div className="row sp"><small>Day {S.day} of 30 · {m.dl} days left</small><small>Income ₹10,000</small></div>
      <div className="big">{fmt(S.bal)}</div><small>current balance</small>
      <div className="bar" style={{margin:'12px 0 6px'}}><i style={{width:S.day/30*100+'%'}}/></div>
      <div className="row sp"><div><small>Safe daily allowance</small><div style={{fontSize:22,fontWeight:800}}>{fmt(m.allow)}</div></div>
      <div style={{textAlign:'right'}}><small>Left today</small><div style={{fontSize:22,fontWeight:800}}>{fmt(left)}</div></div></div></div>
    <div className="grid3">
      <div className="pill"><small>Health</small><b className={hl[1]}>{m.health}</b><small>{hl[0]}</small></div>
      <div className="pill"><small>Risk</small><b className={RC[m.risk]}>{RISK[m.risk]}</b><small>day-30 outlook</small></div>
      <div className="pill"><small>Day-30 cash</small><b className={m.end<0?'bad':''}>{fmt(m.end)}</b><small>forecast</small></div></div>
    <div className="card" style={{marginTop:12}}><h3>Log today's spend</h3>
      <input type="number" inputMode="numeric" placeholder="Amount ₹" value={amt} onChange={e=>setAmt(e.target.value)}/>
      <div className="chips">{Object.keys(CATS).map(c=><span key={c} className={'chip '+(c===cat?'on':'')} onClick={()=>setCat(c)}>{CATS[c]} {c}</span>)}</div>
      <div className="row"><button className="btn" style={{flex:1}} onClick={()=>{if(onLog(+amt))setAmt('')}}>Add expense</button>
      <button className="btn g" style={{flex:1}} onClick={onEnd}>{S.day>=30?'Finish month':`End day ${S.day} →`}</button></div></div>
    <div className="card"><h3>Balance forecast</h3><Chart S={S} m={m}/><div className="mut">Solid = actual · dashed = projection at your pace</div></div>
    <div className="card"><h3>Smart insights</h3>{insights(S,m).map((x,i)=><div className="ins" key={i}>{x}</div>)}</div>
    <div className="card"><h3>Recent activity</h3>
      {S.log.slice(0,5).map((l,i)=><div className="row sp" style={{padding:'6px 0'}} key={i}><span>{l.i} {l.n} <span className="mut">· day {l.d}</span></span><b>-{fmt(l.a)}</b></div>)}
      {!S.log.length&&<span className="mut">Nothing yet. Make your first move.</span>}</div>
  </>
}

function Simulator({S,sim,setSim,onCommit}){
  const upd=p=>setSim({...sim,...p})
  const act=S.subs.map((x,i)=>[x,i]).filter(p=>p[0].on)
  const d={t:sim.t,a:+sim.a||0,n:sim.n,i:+sim.i}
  let body
  if(sim.t==='cancel'&&!act.length) body=<p className="mut">No active subscriptions.</p>
  else if(sim.t!=='cancel'&&!(d.a>0)) body=<p className="mut">Enter an amount to preview the ripple effects.</p>
  else if(sim.t==='goal'&&d.a>S.bal) body=<p className="bad">Not enough balance for that.</p>
  else{
    const b=M(S),s1=ap(clone(S),d),n=M(s1),sa=sim.t==='cancel'?S.subs[d.i]?.a||0:d.a
    const rows=[['Balance',fmt(S.bal),fmt(s1.bal),s1.bal-S.bal,1],['Daily allowance',fmt(b.allow),fmt(n.allow),n.allow-b.allow,1],['Day-30 cash',fmt(b.end),fmt(n.end),n.end-b.end,1],['Goal shortfall',fmt(b.short),fmt(n.short),n.short-b.short,-1],['Risk',RISK[b.risk],RISK[n.risk],n.risk-b.risk,-1],['Health',b.health,n.health,n.health-b.health,1]]
    const dd=n.allow>0?d.a/n.allow:99
    const note=sim.t==='spend'?`This equals ${dd>50?'way more than':dd.toFixed(1)+' days of'} your allowance.`
      :sim.t==='sub'?`Recurring: costs ${fmt(d.a*12)}/year, not just ${fmt(d.a)}.`
      :sim.t==='goal'?`Funds ${S.goals[d.i].n}: ${fmt(S.goals[d.i].saved+d.a)} of ${fmt(S.goals[d.i].target)}.`
      :S.subs[d.i].p?`Already billed this month. Saves ${fmt(sa)} from next month (${fmt(sa*12)}/yr).`:`Saves ${fmt(sa)} this month.`
    body=<>
      <table className="cmp"><tbody><tr><td className="mut">Metric</td><td className="mut">Now</td><td className="mut">After</td></tr>
      {rows.map(r=>{const dl=r[3]*r[4],c=Math.abs(r[3])<1?'':dl>0?'ok':'bad';return <tr key={r[0]}><td>{r[0]}</td><td>{r[1]}</td><td className={c}><b>{r[2]}</b></td></tr>})}</tbody></table>
      <p style={{fontSize:14}}>{note}</p>
      {n.risk>b.risk?<div className="ins" style={{borderColor:'var(--bad)'}}>⚠️ This pushes your risk from {RISK[b.risk]} to {RISK[n.risk]}.</div>
       :n.short>b.short?<div className="ins" style={{borderColor:'var(--warn)'}}>Goal contributions become harder to fund.</div>:null}
      <button className="btn w" onClick={()=>onCommit(d)}>Commit this decision</button></>
  }
  return <>
    <div className="card"><h3>🔮 Decision simulator</h3><p className="mut" style={{marginTop:0}}>Test a choice before you make it. Nothing changes until you commit.</p>
      <div className="chips">{[['spend','Spend once'],['sub','Subscribe'],['goal','Save to goal'],['cancel','Cancel sub']].map(t=>
        <span key={t[0]} className={'chip '+(sim.t===t[0]?'on':'')} onClick={()=>upd({t:t[0],i:0})}>{t[1]}</span>)}</div>
      {sim.t==='cancel'?<select value={sim.i} onChange={e=>upd({i:e.target.value})}>{act.map(p=><option key={p[1]} value={p[1]}>{p[0].n} · {fmt(p[0].a)}</option>)}</select>
      :<>{sim.t==='goal'?<select value={sim.i} style={{marginBottom:8}} onChange={e=>upd({i:e.target.value})}>{S.goals.map((g,i)=><option key={i} value={i}>{g.i} {g.n}</option>)}</select>
        :<input placeholder="What is it?" value={sim.n} style={{marginBottom:8}} onChange={e=>upd({n:e.target.value})}/>}
        <input type="number" inputMode="numeric" placeholder="Amount ₹" value={sim.a} onChange={e=>upd({a:e.target.value})}/></>}
      {(sim.t==='spend'||sim.t==='sub')&&<div className="chips">{PRE.filter(p=>p[0]===sim.t).map(p=><span key={p[1]} className="chip" onClick={()=>upd({n:p[1],a:p[2]})}>{p[1]} {fmt(p[2])}</span>)}</div>}</div>
    <div className="card"><h3>Impact preview</h3>{body}</div></>
}

function Goals({S,m,onAdd}){
  return <>
    <div className="card"><h3>🎯 Savings goals</h3><p className="mut" style={{marginTop:0}}>Plan this month: {fmt(S.goals.reduce((a,g)=>a+g.plan,0))} · still to fund: {fmt(m.reserve)}. Reserved money is removed from your allowance.</p></div>
    {S.goals.map((g,i)=>{const mo=g.plan?Math.ceil((g.target-g.saved)/g.plan):'∞'
      return <div className="card" key={i}><div className="row sp"><b>{g.i} {g.n}</b><span className="tag">{fmt(g.saved)} / {fmt(g.target)}</span></div>
      <div className="bar" style={{margin:'10px 0'}}><i style={{width:clamp(g.saved/g.target*100,0,100)+'%'}}/></div>
      <div className="mut">This month: {fmt(g.c)} of {fmt(g.plan)} · at this pace done in {mo} month{mo===1?'':'s'}</div>
      <div className="row" style={{marginTop:10}}><button className="btn g" onClick={()=>onAdd(i,100)}>+₹100</button><button className="btn g" onClick={()=>onAdd(i,250)}>+₹250</button>
      <button className="btn" onClick={()=>onAdd(i,Math.max(0,g.plan-g.c)||100)}>Fund plan</button></div></div>})}</>
}

function Bills({S,m,onToggle,onRestart}){
  const sub=S.subs.filter(x=>x.on).reduce((a,x)=>a+x.a,0)
  const Row=({x,i,tg})=><div className="row sp" style={{padding:'9px 0',borderBottom:'1px solid var(--line)'}}>
    <div><b>{x.n}</b><div className="mut">{fmt(x.a)} · day {x.d} · {x.p?'paid ✓':x.on===0?'cancelled':'upcoming'}</div></div>
    {tg&&<button className={'tog '+(x.on?'on':'')} disabled={!x.on} onClick={()=>onToggle(i)}/>}</div>
  return <>
    <div className="card"><h3>📌 Commitments</h3><div className="mut">Total {fmt(S.commits.reduce((a,x)=>a+x.a,0))} · fixed bills left this month: {fmt(m.fixedLeft)}</div>{S.commits.map((x,i)=><Row key={i} x={x}/>)}</div>
    <div className="card"><h3>🔁 Subscriptions · {fmt(sub)}/mo</h3><div className="mut">{fmt(sub*12)}/year · {Math.round(sub/100)}% of income. Toggle off to cancel.</div>{S.subs.map((x,i)=><Row key={i} x={x} i={i} tg/>)}</div>
    <div className="card"><button className="btn g w" onClick={()=>confirm('Restart the 30 days?')&&onRestart()}>↺ Restart simulation</button></div></>
}

function Final({S,m,onRestart}){
  const g=S.goals.reduce((a,x)=>a+x.saved,0),hl=HL(m.health)
  return <><div className="card hero"><small>30 days complete 🎉</small><div className="big">{m.health}/100</div><div style={{fontSize:20,fontWeight:700}}>{hl[0]} financial health</div></div>
    <div className="card"><table className="cmp"><tbody>
      <tr><td>Cash left</td><td><b>{fmt(S.bal)}</b></td></tr><tr><td>Saved in goals</td><td><b>{fmt(g)}</b></td></tr>
      <tr><td>Net worth gained</td><td><b>{fmt(S.bal+g)}</b></td></tr><tr><td>Days over allowance</td><td><b>{S.over}</b></td></tr>
      <tr><td>Final risk</td><td className={RC[m.risk]}><b>{RISK[m.risk]}</b></td></tr></tbody></table></div>
    <button className="btn w" onClick={onRestart}>Play again with new choices</button></>
}

export default function App(){
  const [S,setS]=useState(()=>load()||init())
  const [tab,setTab]=useState('home'),[cat,setCat]=useState('Food'),[toast,setToast]=useState('')
  const [sim,setSim]=useState({t:'spend',a:'',n:'',i:0})
  const th=useRef()
  useEffect(()=>{try{localStorage.setItem(KEY,JSON.stringify(S))}catch{}},[S])
  const say=t=>{setToast(t);clearTimeout(th.current);th.current=setTimeout(()=>setToast(''),2400)}
  const mut=fn=>{const n=clone(S);fn(n);setS(n)}
  const m=M(S)
  const onLog=a=>{if(!(a>0)){say('Enter an amount');return false}
    mut(n=>{ap(n,{t:'spend',a,n:cat,icon:CATS[cat]})});say(`${fmt(a)} logged`);return true}
  const onEnd=()=>{if(S.event)return say('Handle the surprise expense first')
    mut(n=>{if(n.spent>n.todayAllow+1)n.over++;n.hist.push(n.bal)
      if(n.day>=30){n.done=true;return}
      n.day++;n.spent=0;charge(n);n.event=rollEvent(n.day);n.todayAllow=M(n).allow});window.scrollTo(0,0)}
  const onPay=mode=>{const e=S.event
    if(mode==='ef'&&S.goals[0].saved<e.a)return say('Not enough in emergency fund')
    mut(n=>{if(mode==='ef'){const g=n.goals[0];g.saved-=e.a;g.c=Math.max(0,g.c-e.a);n.log.unshift({n:e.n+' (emergency fund)',a:e.a,d:n.day,i:e.i})}
      else{n.bal-=e.a;n.spent+=e.a;n.log.unshift({n:e.n,a:e.a,d:n.day,i:e.i})}
      n.event=null});say('Handled. Forecast updated')}
  const onAdd=(i,a)=>{if(S.bal<a)return say('Not enough balance');mut(n=>{ap(n,{t:'goal',a,i})});say('Saved '+fmt(a))}
  const onToggle=i=>mut(n=>{ap(n,{t:'cancel',i})})
  const onCommit=d=>{mut(n=>{ap(n,d)});setSim({...sim,a:'',n:''});say('Decision committed · everything updated');setTab('home')}
  const onRestart=()=>{resetSeed();setS(init());setTab('home')}
  const tabs=[['home','🏠','Home'],['sim','🔮','Simulate'],['goals','🎯','Goals'],['bills','🔁','Bills']]
  return <>
    <div className="toast" style={{opacity:toast?1:0}}>{toast}</div>
    <div id="root-inner" style={{maxWidth:560,margin:'0 auto',padding:'14px 14px 90px'}}>
      <div className="row sp" style={{margin:'4px 2px 12px'}}><b style={{fontSize:20}}>💸 PaisaPilot</b><span className="mut">₹10k · 30 days</span></div>
      {S.done?<Final S={S} m={m} onRestart={onRestart}/>
      :tab==='home'?<Home S={S} m={m} cat={cat} setCat={setCat} onLog={onLog} onEnd={onEnd} onPay={onPay}/>
      :tab==='sim'?<Simulator S={S} sim={sim} setSim={setSim} onCommit={onCommit}/>
      :tab==='goals'?<Goals S={S} m={m} onAdd={onAdd}/>
      :<Bills S={S} m={m} onToggle={onToggle} onRestart={onRestart}/>}
    </div>
    <nav><div>{tabs.map(t=><button key={t[0]} className={tab===t[0]?'on':''} onClick={()=>{setTab(t[0]);window.scrollTo(0,0)}}><span>{t[1]}</span>{t[2]}</button>)}</div></nav>
  </>
}
