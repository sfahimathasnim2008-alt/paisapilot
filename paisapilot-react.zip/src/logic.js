export const clamp=(v,a,b)=>Math.max(a,Math.min(b,v))
export const fmt=n=>(n<0?'-':'')+'₹'+Math.abs(Math.round(n)).toLocaleString('en-IN')
export const CATS={Food:'🍜',Transport:'🚌',Fun:'🎮',Shopping:'🛍️',Study:'📚',Other:'✨'}
export const RISK=['Low','Medium','High'],RC=['ok','warn','bad']
export const HL=h=>h>=75?['Thriving','ok']:h>=55?['Stable','ok']:h>=35?['Shaky','warn']:['Critical','bad']
const SHOCKS=[{n:'Phone screen cracked',a:1200,i:'📱'},{n:"Best friend's birthday",a:600,i:'🎂'},{n:'Laptop charger died',a:900,i:'🔌'},{n:'Sudden clinic visit',a:700,i:'🩺'},{n:'Group project print + travel',a:450,i:'🖨️'}]
let seed=11
export const resetSeed=()=>{seed=11}
function rnd(){seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}
export const rollEvent=day=>([8,19,26].includes(day)||rnd()<.1)?{...SHOCKS[Math.floor(rnd()*SHOCKS.length)]}:null
export const clone=s=>JSON.parse(JSON.stringify(s))
export function charge(s){[...s.commits,...s.subs.filter(x=>x.on)].forEach(x=>{if(!x.p&&x.d<=s.day){x.p=1;s.bal-=x.a}})}
export function init(){const s={day:1,bal:10000,spent:0,varT:0,over:0,todayAllow:0,hist:[],log:[],event:null,done:false,
commits:[{n:'Rent share',a:2500,d:1},{n:'Transport pass',a:600,d:5},{n:'Mobile recharge',a:299,d:10}],
subs:[{n:'Spotify',a:119,d:3,on:1},{n:'Netflix',a:199,d:12,on:1},{n:'Gym',a:499,d:15,on:1},{n:'Cloud storage',a:75,d:20,on:1}],
goals:[{n:'Emergency fund',i:'🛟',plan:1000,c:0,saved:0,target:5000},{n:'Goa trip',i:'🏖️',plan:800,c:0,saved:0,target:6000},{n:'Headphones',i:'🎧',plan:500,c:0,saved:0,target:3000}]}
charge(s);s.todayAllow=M(s).allow;return s}
export function M(s){const it=[...s.commits,...s.subs.filter(x=>x.on)],fixedAll=it.reduce((a,x)=>a+x.a,0),fixedLeft=it.filter(x=>!x.p).reduce((a,x)=>a+x.a,0)
const reserve=s.goals.reduce((a,g)=>a+Math.max(0,g.plan-g.c),0),sumPlan=s.goals.reduce((a,g)=>a+g.plan,0),sumC=s.goals.reduce((a,g)=>a+g.c,0)
const free=s.bal-fixedLeft-reserve-500,dl=Math.max(1,31-s.day),allow=Math.max(0,free)/dl
const avg=(s.varT+300)/(s.day+2),end=s.bal-fixedLeft-reserve-avg*dl,short=Math.max(0,-free)
const risk=end<0?2:(end<600||s.bal-fixedLeft<1000)?1:0
const covered=free>=0?reserve:Math.max(0,reserve+free)
const h=clamp(end/1500,0,1)*30+clamp(1-(fixedAll/10000-.3)/.3,0,1)*20+clamp((sumC+.5*covered)/sumPlan,0,1)*25+(s.day>1?clamp(1-s.over/(s.day-1),0,1):1)*15+clamp((s.bal-fixedLeft)/1500,0,1)*10
return{fixedAll,fixedLeft,reserve,free,allow,avg,end,short,risk,health:Math.round(h),dl}}
export function ap(s,d){const a=d.a
if(d.t==='spend'){s.bal-=a;s.spent+=a;if(a<=1000)s.varT+=a;s.log.unshift({n:d.n||'Spend',a,d:s.day,i:d.icon||'💸'})}
if(d.t==='sub'){s.subs.push({n:d.n||'New sub',a,d:s.day,on:1,p:0});charge(s);s.log.unshift({n:'Sub: '+(d.n||'New'),a,d:s.day,i:'🔁'})}
if(d.t==='goal'){s.bal-=a;const g=s.goals[d.i];g.c+=a;g.saved+=a;s.log.unshift({n:'Saved → '+g.n,a,d:s.day,i:g.i})}
if(d.t==='cancel')s.subs[d.i].on=0
return s}
export function insights(s,m){const o=[]
if(m.short>0)o.push(`⚠️ You're ${fmt(m.short)} short of covering bills + goal contributions. Cut spending, pause a goal or cancel a sub.`)
if(m.end<0)o.push(`🔴 At your current pace you'll run out of money before Day 30 (${fmt(m.end)}).`)
else o.push(`📈 At your current pace you finish Day 30 with ${fmt(m.end)} after paying all bills and funding goals.`)
const sub=s.subs.filter(x=>x.on).reduce((a,x)=>a+x.a,0)
if(sub>=700)o.push(`🔁 Subscriptions take ${fmt(sub)}/mo (${Math.round(sub/100)}% of income). Trim one?`)
if(m.avg>m.allow*1.15&&m.allow>0)o.push(`🍜 You average ${fmt(m.avg)}/day but your safe allowance is ${fmt(m.allow)}. Slow down.`)
if(s.bal-m.fixedLeft<1000)o.push('🛟 Your cushion for surprises is thin. One ₹1,000 shock would hurt.')
return o.slice(0,4)}
